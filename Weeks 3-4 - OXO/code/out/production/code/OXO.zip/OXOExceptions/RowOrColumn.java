package OXOExceptions;

public enum RowOrColumn { ROW, COLUMN }
